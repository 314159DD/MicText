#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::io::{BufRead, BufReader};
use std::process::{Command, Stdio};
use tauri::{AppHandle, Manager};
use tauri::Emitter;

#[tauri::command]
fn start_transcription(app: AppHandle) {
    let window = app.get_webview_window("main").expect("main window not found");

    std::thread::spawn(move || {
        let mut child = Command::new("python")
            .arg("transcribe.py")
            .stdout(Stdio::piped())
            .spawn()
            .expect("Failed to start transcribe.py");

        if let Some(stdout) = child.stdout.take() {
            let reader = BufReader::new(stdout);
            for line in reader.lines() {
                if let Ok(text) = line {
                    window.emit("transcript", text).unwrap();
                }
            }
        }
    });
}

#[tauri::command]
fn stop_transcription() {
    // TODO: add process kill later
}

#[tauri::command]
fn start_recording() -> String {
    println!("Recording started from UI");
    "Mic capture triggered (stub)".to_string()
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![start_transcription, stop_transcription, start_recording])
        .run(tauri::generate_context!())
        .expect("error while running tauri app");
}
